import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app/main_shell.dart';
import 'core/providers/holdings_provider.dart';
import 'core/providers/orders_provider.dart';
import 'core/providers/wallet_provider.dart';
import 'core/providers/watchlist_provider.dart';
import 'core/services/market_data_service.dart';
import 'core/services/persistence_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final persistence = PersistenceService();
  await persistence.init();

  final market = MarketDataService(ticksPerSecondPerStock: 1.5);
  market.start();

  runApp(TradingApp(persistence: persistence, market: market));
}

class TradingApp extends StatelessWidget {
  const TradingApp({super.key, required this.persistence, required this.market});

  final PersistenceService persistence;
  final MarketDataService market;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<MarketDataService>.value(value: market),
        ChangeNotifierProvider<WatchlistProvider>(
          create: (_) => WatchlistProvider(persistence)..load(),
        ),
        ChangeNotifierProvider<WalletProvider>(
          create: (_) => WalletProvider(persistence)..load(),
        ),
        ChangeNotifierProvider<OrdersProvider>(
          create: (_) => OrdersProvider(persistence)..load(),
        ),
        ChangeNotifierProvider<HoldingsProvider>(
          create: (_) => HoldingsProvider(persistence, market)..load(),
        ),
      ],
      child: MaterialApp(
        title: 'Trading App',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: Colors.indigo,
          useMaterial3: true,
        ),
        home: const MainShell(),
      ),
    );
  }
}
