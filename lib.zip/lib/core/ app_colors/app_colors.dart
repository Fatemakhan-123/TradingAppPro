import 'package:flutter/material.dart';

class AppColors {

  static final Color blackColor=Colors.black;
  static final Color whiteColor=Colors.white;
}