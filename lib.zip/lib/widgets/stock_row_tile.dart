import 'package:flutter/material.dart';

import '../core/models/stock.dart';
import '../core/services/market_data_service.dart';
import 'flash_price_cell.dart';

class StockRowTile extends StatelessWidget {
  const StockRowTile({
    super.key,
    required this.symbol,
    required this.market,
    this.onTap,
    this.trailingLeadingWidget,
    this.dragHandle,
  });

  final String symbol;
  final MarketDataService market;
  final VoidCallback? onTap;
  final Widget? trailingLeadingWidget;
  final Widget? dragHandle;

  @override
  Widget build(BuildContext context) {
    final info = kStockUniverseBySymbol[symbol];
    return ListTile(
      onTap: onTap,
      leading: dragHandle,
      title: Text(symbol, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(info?.name ?? symbol, overflow: TextOverflow.ellipsis),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailingLeadingWidget != null) trailingLeadingWidget!,
          FlashPriceCell(quoteListenable: market.quoteNotifier(symbol)),
        ],
      ),
    );
  }
}
