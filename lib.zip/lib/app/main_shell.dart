import 'package:flutter/material.dart';
import 'package:task_trading_app/core/%20app_colors/app_colors.dart';

import '../screens/holdings/holdings_screen.dart';
import '../screens/live_prices/live_prices_screen.dart';
import '../screens/watchlist/watchlist_list_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {

  ValueNotifier<int> currentIndex=ValueNotifier<int>(0);
  static const _screens = [
    WatchlistListScreen(),
    LivePricesScreen(),
    HoldingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blackColor,
      body:ValueListenableBuilder(valueListenable: currentIndex, builder: (context, value, child) {
        return  IndexedStack(index:value, children: _screens);
      },),
      bottomNavigationBar: ValueListenableBuilder(valueListenable: currentIndex, builder: (context, value, child) {
        return SizedBox(
          height: 65,
          child: NavigationBar(
            selectedIndex:value,
            backgroundColor: Colors.black,
            labelTextStyle: WidgetStatePropertyAll(TextStyle(
              color: AppColors.whiteColor,
              fontSize: 12
            )),
            onDestinationSelected: (i){
              currentIndex.value = i;
            },
            destinations: const [
              NavigationDestination(icon: Icon(Icons.star_border,size: 18,), selectedIcon: Icon(Icons.star,size: 18,), label: 'Watchlist'),
              NavigationDestination(icon: Icon(Icons.show_chart,size: 18,),selectedIcon: Icon(Icons.show_chart,size: 18,), label: 'Live Prices'),
              NavigationDestination(icon: Icon(Icons.pie_chart_outline,size: 18,), selectedIcon: Icon(Icons.pie_chart,size: 18,), label: 'Holdings'),
            ],
          ),
        );
      },),
    );
  }
}
