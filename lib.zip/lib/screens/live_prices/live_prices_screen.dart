import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/models/stock.dart';
import '../../core/services/market_data_service.dart';
import '../../widgets/stock_row_tile.dart';
import '../ticket/buy_sell_ticket_screen.dart';

class LivePricesScreen extends StatefulWidget {
  const LivePricesScreen({super.key});

  @override
  State<LivePricesScreen> createState() => _LivePricesScreenState();
}

class _LivePricesScreenState extends State<LivePricesScreen> {
  @override
  Widget build(BuildContext context) {
    final market = context.read<MarketDataService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Live Prices'),
        actions: [
          IconButton(
            icon: const Icon(Icons.speed),
            tooltip: 'Tick rate',
            onPressed: () => _showRateSheet(context, market),
          ),
        ],
      ),
      // A plain ListView is enough here: each row is a StockRowTile that
      // binds directly to its own ValueNotifier<Quote>, so scrolling stays
      // smooth and a tick on one symbol never rebuilds this ListView itself.
      body: ListView.separated(
        itemCount: kStockUniverse.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final symbol = kStockUniverse[index].symbol;
          return StockRowTile(
            key: ValueKey('live_$symbol'),
            symbol: symbol,
            market: market,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => BuySellTicketScreen(symbol: symbol)),
              );
            },
          );
        },
      ),
    );
  }

  void _showRateSheet(BuildContext context, MarketDataService market) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            final rate = market.ticksPerSecondPerStock;
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Tick rate: ${rate.toStringAsFixed(1)}/sec per stock '
                    '(~${(rate * kStockUniverse.length).toStringAsFixed(0)}/sec overall)',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Slider(
                    min: 0.2,
                    max: 8,
                    divisions: 39,
                    value: rate,
                    label: rate.toStringAsFixed(1),
                    onChanged: (v) {
                      market.setTicksPerSecondPerStock(v);
                      setSheetState(() {});
                    },
                  ),
                  const Text(
                    'Try 5+/sec to stress-test — the feed is the single '
                    'source of truth used everywhere in the app.',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
