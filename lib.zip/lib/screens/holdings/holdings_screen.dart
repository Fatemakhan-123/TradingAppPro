import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task_trading_app/core/%20app_colors/app_colors.dart';

import '../../core/models/holding.dart';
import '../../core/models/stock.dart';
import '../../core/money.dart';
import '../../core/providers/holdings_provider.dart';
import '../ticket/buy_sell_ticket_screen.dart';

class HoldingsScreen extends StatelessWidget {
  const HoldingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blackColor,
      appBar: AppBar(
        title: Text('Holdings',style: TextStyle(color: AppColors.blackColor,fontWeight: FontWeight.w500,fontSize: 20),),
        actions: [
          Consumer<HoldingsProvider>(
            builder: (context, holdings, _) {
              return PopupMenuButton<HoldingsSortField>(
                icon: const Icon(Icons.sort,size: 25,),
                tooltip: 'Sort',
                onSelected: (field) => holdings.setSort(field),
                itemBuilder: (ctx) => [
                  _sortItem(holdings, HoldingsSortField.pnl, 'P&L'),
                  _sortItem(holdings, HoldingsSortField.symbol, 'Symbol'),
                  _sortItem(holdings, HoldingsSortField.currentValue, 'Current value'),
                ],
              );
            },
          ),
        ],
      ),
      body: Consumer<HoldingsProvider>(
        builder: (context, holdings, _) {
          if (holdings.isEmpty) {
            return Center(
              child: Padding(
                padding: EdgeInsets.all(8.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.inbox_outlined, size: 50, color:AppColors.whiteColor),
                    SizedBox(height: 12),
                    Text('No holdings yet',style: TextStyle(color:AppColors.whiteColor,fontSize: 13),),
                    SizedBox(height: 4),
                    Text('Buy a stock from Watchlist or Live Prices to see it here.',
                        style: TextStyle(color:AppColors.whiteColor,fontSize: 13), textAlign: TextAlign.center),
                  ],
                ),
              ),
            );
          }

          return Column(
            children: [
              _AggregateSummary(holdings: holdings),
              const Divider(height: 1),
              Expanded(
                child: ListView.separated(
                  itemCount: holdings.rows.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final row = holdings.rows[index];
                    return _HoldingRowTile(row: row);
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  PopupMenuItem<HoldingsSortField> _sortItem(
      HoldingsProvider holdings, HoldingsSortField field, String label) {
    final active = holdings.sortField == field;
    return PopupMenuItem(
      value: field,
      child: Row(
        children: [
          if (active)
            Icon(holdings.descending ? Icons.arrow_downward : Icons.arrow_upward, size: 18),
          if (active) const SizedBox(width: 6),
          Text(label, style: TextStyle(fontWeight: active ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }
}

class _AggregateSummary extends StatelessWidget {
  const _AggregateSummary({required this.holdings});

  final HoldingsProvider holdings;

  @override
  Widget build(BuildContext context) {
    final pnl = Money(holdings.totalPnlPaise);
    final up = holdings.totalPnlPaise >= 0;
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(child: _statColumn('Invested', Money(holdings.totalInvestedPaise).formatted)),
          Expanded(child: _statColumn('Current value', Money(holdings.totalCurrentValuePaise).formatted)),
          Expanded(
            child: _statColumn(
              'Total P&L',
              '${up ? '+' : ''}${pnl.formattedPlain} (${up ? '+' : ''}${holdings.totalPnlPercent.toStringAsFixed(2)}%)',
              color: up ? Colors.green.shade700 : Colors.red.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _statColumn(String label, String value, {Color? color}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        const SizedBox(height: 4),
        Text(value,
            style: TextStyle(fontWeight: FontWeight.bold, color: color),
            overflow: TextOverflow.ellipsis),
      ],
    );
  }
}

class _HoldingRowTile extends StatelessWidget {
  const _HoldingRowTile({required this.row});

  final HoldingRow row;

  @override
  Widget build(BuildContext context) {
    final info = kStockUniverseBySymbol[row.symbol];
    final up = row.pnlPaise >= 0;
    final pnlColor = up ? Colors.green.shade700 : Colors.red.shade700;

    return ListTile(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => BuySellTicketScreen(symbol: row.symbol)),
        );
      },
      title: Text(row.symbol, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(
        '${row.quantity} sh · avg ${Money(row.avgCostPaise).formatted} · ${info?.name ?? ''}',
        overflow: TextOverflow.ellipsis,
      ),
      trailing: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(Money(row.currentValuePaise).formatted, style: const TextStyle(fontWeight: FontWeight.w600)),
          Text(
            '${up ? '+' : ''}${Money(row.pnlPaise).formattedPlain} (${up ? '+' : ''}${row.pnlPercent.toStringAsFixed(2)}%)',
            style: TextStyle(color: pnlColor, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
